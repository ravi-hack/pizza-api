this application has not guarantee of performing as expected and i will not be held responsible for any malfunctions
anyone can download and use the source code however they desire

