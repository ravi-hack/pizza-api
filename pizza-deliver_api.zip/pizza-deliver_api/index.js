/*
*Entry file for Application initialisation
*
*/

//Dependencies
var server = require('./lib/server');
//starting the server
server.init(); 
